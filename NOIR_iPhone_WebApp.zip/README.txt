NOIR iPhone web-app starter

This is a local-first Progressive Web App prototype, not an App Store app.
It must be published to an HTTPS website before Safari can add it to the Home Screen.
After opening the HTTPS site in Safari, use Share > Add to Home Screen.
Wardrobe, outfits and journal are saved in Safari localStorage on this device.
Do not clear website data or delete the site if you need these records.
No cloud sync or generative AI model is included yet.
